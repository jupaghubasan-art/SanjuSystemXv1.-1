package com.sanju.systemx.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import android.view.Choreographer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class Monitor(private val ctx: Context) {
    data class Sample(
        val fps: Float, val ramPct: Float, val ramText: String, val heapMb: Long,
        val battery: Int, val charging: Boolean, val tempC: Float?, val cpu: String
    )

    private var frames = 0
    private var running = false
    private var lastTs = 0L
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        if (running) return
        running = true; frames = 0; lastTs = SystemClock.elapsedRealtime()
        Choreographer.getInstance().postFrameCallback(cb)
    }

    fun stop() { running = false }

    suspend fun sample(): Sample {
        val now = SystemClock.elapsedRealtime()
        val dt = (now - lastTs).coerceAtLeast(1L)
        lastTs = now
        val fps = frames * 1000f / dt
        frames = 0

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val used = mi.totalMem - mi.availMem
        val rt = Runtime.getRuntime()
        val heap = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)

        val b: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val t = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val cpu = withContext(Dispatchers.IO) { cpuText() }

        return Sample(
            fps = fps,
            ramPct = used * 100f / mi.totalMem,
            ramText = String.format(Locale.US, "%d / %d MB", used / 1048576, mi.totalMem / 1048576),
            heapMb = heap,
            battery = if (lvl >= 0) lvl * 100 / scale else -1,
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL,
            tempC = if (t == Int.MIN_VALUE) null else t / 10f,
            cpu = cpu
        )
    }

    private fun cpuText(): String {
        val n = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until n).map {
            File("/sys/devices/system/cpu/cpu$it/cpufreq/scaling_cur_freq")
                .runCatching { readText().trim().toLong() / 1000 }.getOrNull()
        }
        val detail = if (freqs.all { it == null }) "core frequency unavailable (restricted by Android)"
        else freqs.joinToString(" / ") { it?.toString() ?: "?" } + " MHz"
        return "$n cores · $detail"
    }
}
