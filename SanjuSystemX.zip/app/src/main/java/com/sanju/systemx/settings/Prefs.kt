package com.sanju.systemx.settings

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sanju_systemx", Context.MODE_PRIVATE)

    fun getB(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun setB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun getI(k: String, d: Int): Int = sp.getInt(k, d)
    fun setI(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun getF(k: String, d: Float): Float = sp.getFloat(k, d)
    fun setF(k: String, v: Float) { sp.edit().putFloat(k, v).apply() }
    fun getS(k: String, d: String): String = sp.getString(k, d) ?: d
    fun setS(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun clear() { sp.edit().clear().apply() }
}
