package com.sanju.systemx.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Minimal live line chart. Only plots values that were really measured. */
class LineChartView(c: Context, private val title: String, private val fixedMax: Float?) : View(c) {
    private val data = ArrayDeque<Float>()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Pal.RED; style = Paint.Style.STROKE; strokeWidth = c.dp(2).toFloat()
    }
    private val grid = Paint().apply { color = 0x33888888; strokeWidth = 1f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.sub; textSize = c.dp(11).toFloat() }

    fun push(v: Float) {
        if (data.size >= 60) data.removeFirst()
        data.addLast(v)
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(110))
    }

    override fun onDraw(canvas: Canvas) {
        val top = context.dp(18).toFloat()
        val bottom = height - 4f
        val maxV = fixedMax ?: ((data.maxOrNull() ?: 1f).coerceAtLeast(1f) * 1.2f)
        canvas.drawText(title + (data.lastOrNull()?.let { "  ·  " + Math.round(it) } ?: ""), 4f, top - 6f, txt)
        for (i in 0..2) { val y = top + (bottom - top) * i / 2f; canvas.drawLine(0f, y, width.toFloat(), y, grid) }
        if (data.size < 2) return
        val path = Path()
        val step = width / 59f
        data.forEachIndexed { i, v ->
            val x = i * step
            val y = bottom - (v / maxV).coerceIn(0f, 1f) * (bottom - top)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, line)
    }
}
