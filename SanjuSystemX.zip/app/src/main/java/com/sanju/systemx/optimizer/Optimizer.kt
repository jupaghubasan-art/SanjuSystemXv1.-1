package com.sanju.systemx.optimizer

import android.app.Activity
import android.view.WindowManager
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs

data class Action(val mark: String, val text: String)

enum class Preset(
    val title: String, val desc: String, val rate: String,
    val awake: Boolean, val clear: Boolean, val gfx: String, val fps: String
) {
    LOW("Low Graphics", "Lowest supported refresh rate to save battery, clears this app's cache, records a Low graphics target.", "min", false, true, "Low", "30 FPS"),
    SMOOTH("Smooth Gameplay", "Highest supported refresh rate, keeps the screen awake, records a Medium graphics target.", "max", true, true, "Medium", "60 FPS"),
    BALANCED("Balanced", "Middle refresh rate, no cache clearing, records a High graphics target.", "mid", false, false, "High", "60 FPS"),
    PERFORMANCE("Performance", "Highest supported refresh rate, keeps the screen awake, clears this app's cache.", "max", true, true, "Very High", "90 FPS"),
    DEFAULT("Default", "Restores the system refresh-rate choice and normal screen timeout.", "default", false, false, "Medium", "60 FPS")
}

class Optimizer(private val a: Activity, private val p: Prefs) {

    fun refresh(modeId: Int, hz: Int): Action {
        DisplayCtl.apply(a, modeId)
        p.setI("mode", modeId)
        return Action("✔", "Requested $hz Hz for this app's window. Android decides the final rate.")
    }

    fun keepAwake(on: Boolean): Action {
        if (on) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        p.setB("awake", on)
        return Action("✔", "Keep screen awake ${if (on) "enabled" else "disabled"} for this app.")
    }

    fun clearCache(): Action {
        var bytes = 0L
        a.cacheDir.listFiles()?.forEach { f ->
            bytes += f.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            f.deleteRecursively()
        }
        return Action("✔", "Cleared ${bytes / 1024} KB of this app's own cache.")
    }

    fun gameNote(fps: String, gfx: String) = Action(
        "ℹ", "FPS target ($fps) and graphics ($gfx) were saved only. Not directly controllable by Android — requires device/game support. Set them inside the game."
    )

    fun apply(pr: Preset): List<Action> {
        val out = mutableListOf<Action>()
        val rs = DisplayCtl.rates(a)
        if (pr.rate == "default") {
            DisplayCtl.reset(a); p.setI("mode", 0)
            out += Action("✔", "Refresh-rate preference reset to system default.")
        } else if (rs.size < 2) {
            out += Action("ℹ", "Display reports a single refresh rate (${DisplayCtl.hz(a)} Hz); nothing to change.")
        } else {
            val r = when (pr.rate) { "min" -> rs.first(); "max" -> rs.last(); else -> rs[rs.size / 2] }
            out += refresh(r.modeId, r.hz)
        }
        out += keepAwake(pr.awake)
        if (pr.clear) out += clearCache()
        if (pr != Preset.DEFAULT) {
            p.setS("fps", pr.fps); p.setS("gfx", pr.gfx)
            out += gameNote(pr.fps, pr.gfx)
        }
        return out
    }
}
