package com.sanju.systemx.resolution

import android.app.Activity
import android.os.Build
import android.view.Display

object DisplayCtl {
    data class Rate(val modeId: Int, val hz: Int)

    @Suppress("DEPRECATION")
    fun display(a: Activity): Display =
        if (Build.VERSION.SDK_INT >= 30) (a.display ?: a.windowManager.defaultDisplay)
        else a.windowManager.defaultDisplay

    fun hz(a: Activity): Int = Math.round(display(a).refreshRate)

    /** Physical resolution of the current display mode. */
    fun resolution(a: Activity): Pair<Int, Int> {
        val m = display(a).mode
        return m.physicalWidth to m.physicalHeight
    }

    /** Refresh rates the display reports at its current resolution. */
    fun rates(a: Activity): List<Rate> {
        val d = display(a)
        val cur = d.mode
        return d.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .groupBy { Math.round(it.refreshRate) }
            .map { (hz, list) -> Rate(list.first().modeId, hz) }
            .sortedBy { it.hz }
    }

    /** Sets the preferred display mode for this app's window only. 0 restores the system default. */
    fun apply(a: Activity, modeId: Int) {
        val lp = a.window.attributes
        lp.preferredDisplayModeId = modeId
        a.window.attributes = lp
    }

    fun reset(a: Activity) = apply(a, 0)
}
