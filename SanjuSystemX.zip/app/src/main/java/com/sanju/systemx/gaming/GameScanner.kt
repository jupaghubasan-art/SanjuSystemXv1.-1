package com.sanju.systemx.gaming

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo

data class Game(val label: String, val pkg: String, val isMl: Boolean)

object GameScanner {
    /** Lists launcher apps; by default only those Android categorises as games (plus Mobile Legends by name). */
    @Suppress("DEPRECATION")
    fun scan(ctx: Context, all: Boolean): List<Game> {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != ctx.packageName }
            .map { ai ->
                val l = pm.getApplicationLabel(ai).toString()
                Triple(ai, l, l.contains("mobile legends", ignoreCase = true))
            }
            .filter { all || it.first.category == ApplicationInfo.CATEGORY_GAME || it.third }
            .map { Game(it.second, it.first.packageName, it.third) }
            .sortedWith(compareByDescending<Game> { it.isMl }.thenBy { it.label.lowercase() })
    }
}
