package com.sanju.systemx

import android.animation.Animator
import android.animation.ObjectAnimator
import android.content.res.ColorStateList
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.sanju.systemx.monitor.Monitor
import com.sanju.systemx.optimizer.Optimizer
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.ui.*
import kotlinx.coroutines.Job

class MainActivity : AppCompatActivity() {
    lateinit var prefs: Prefs
    lateinit var monitor: Monitor
    lateinit var optimizer: Optimizer
    private lateinit var content: FrameLayout
    private lateinit var rootView: LinearLayout
    private var pulse: Animator? = null
    var tab: Int = R.id.nav_dashboard
    var monitorJob: Job? = null
    var probeAnim: Animator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        Pal.dark = prefs.getB("dark", true)
        Pal.haptic = prefs.getB("haptic", true)
        Pal.anim = prefs.getB("anim", true)
        monitor = Monitor(this)
        optimizer = Optimizer(this, prefs)
        tab = savedInstanceState?.getInt("tab", R.id.nav_dashboard) ?: R.id.nav_dashboard

        window.statusBarColor = Pal.bg
        window.navigationBarColor = Pal.panel
        if (prefs.getB("awake", false)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val mode = prefs.getI("mode", 0)
        if (mode != 0) DisplayCtl.apply(this, mode)

        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.bg)
        }
        rootView.addView(header())
        content = FrameLayout(this)
        rootView.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        rootView.addView(nav())
        setContentView(rootView)
        applyAnime(prefs.getB("anime", false))
        show(tab)
    }

    private fun header(): View {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.panel)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        h.addView(label("SANJU SYSTEM X", 20f, Pal.RED, true).apply { letterSpacing = 0.12f })
        h.addView(label("ANDROID GAME OPTIMIZER", 11f, Pal.sub).apply { letterSpacing = 0.2f })
        val status = label("● SYSTEM ONLINE", 12f, Pal.GREEN, true)
        h.addView(status)
        if (Pal.anim) {
            // Short, finite pulse (no endless animation, to save battery).
            pulse = ObjectAnimator.ofFloat(status, "alpha", 1f, 0.3f).apply {
                duration = 700; repeatCount = 3; repeatMode = android.animation.ValueAnimator.REVERSE; start()
            }
        }
        return h
    }

    private fun nav(): View = BottomNavigationView(this).apply {
        inflateMenu(R.menu.nav)
        setBackgroundColor(Pal.panel)
        val cs = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Pal.RED, Pal.sub)
        )
        itemIconTintList = cs
        itemTextColor = cs
        selectedItemId = tab
        setOnItemSelectedListener { tab = it.itemId; show(it.itemId); true }
    }

    fun show(id: Int) {
        stopMonitor()
        content.removeAllViews()
        val v: View = when (id) {
            R.id.nav_resolution -> resolutionScreen()
            R.id.nav_gaming -> gamingScreen()
            R.id.nav_monitor -> monitorScreen()
            R.id.nav_settings -> settingsScreen()
            else -> dashboardScreen()
        }
        val sv = ScrollView(this).apply { addView(v); isFillViewport = true }
        content.addView(sv)
        if (Pal.anim) { sv.alpha = 0f; sv.animate().alpha(1f).setDuration(220).start() }
    }

    fun stopMonitor() {
        monitorJob?.cancel(); monitorJob = null
        probeAnim?.cancel(); probeAnim = null
        monitor.stop()
    }

    /** Visual-only filter applied to this app's own UI. It does not touch any game. */
    fun applyAnime(on: Boolean) {
        if (!on) { rootView.setLayerType(View.LAYER_TYPE_NONE, null); return }
        val cm = ColorMatrix().apply { setSaturation(1.45f) }
        val c = 1.12f
        val t = (-0.5f * c + 0.5f) * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f)))
        rootView.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
    }

    override fun onPause() { super.onPause(); stopMonitor() }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized && tab == R.id.nav_monitor && monitorJob?.isActive != true) show(tab)
    }

    override fun onDestroy() { pulse?.cancel(); stopMonitor(); super.onDestroy() }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }
}
