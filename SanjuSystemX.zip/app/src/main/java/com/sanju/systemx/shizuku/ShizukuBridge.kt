package com.sanju.systemx.shizuku

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_INSTALLED, NOT_RUNNING, NEEDS_PERMISSION, CONNECTED }

/**
 * Optional privileged access through Shizuku. Only the two whitelisted `wm size` commands can ever run,
 * and the UI always shows the exact command and asks for confirmation first.
 */
object ShizukuBridge {
    private const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4242
    private val sizeArg = Regex("^\\d{3,5}x\\d{3,5}$")

    data class Result(val code: Int, val out: String)

    @Suppress("DEPRECATION")
    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0); true
    } catch (e: Exception) { false }

    fun state(ctx: Context): ShizukuState {
        if (!isInstalled(ctx)) return ShizukuState.NOT_INSTALLED
        val running = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        if (!running) return ShizukuState.NOT_RUNNING
        val ok = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
        return if (ok) ShizukuState.CONNECTED else ShizukuState.NEEDS_PERMISSION
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (e: Throwable) { /* not running */ }
    }

    fun statusText(ctx: Context): String = when (state(ctx)) {
        ShizukuState.NOT_INSTALLED -> "Shizuku is not installed.\nAdvanced system operations unavailable.\nShizuku Status: Not Connected"
        ShizukuState.NOT_RUNNING -> "Shizuku is installed but not running. Open the Shizuku app and start it (Wireless debugging), then tap the button below.\nShizuku Status: Not Connected"
        ShizukuState.NEEDS_PERMISSION -> "Shizuku is running. Tap the button below and allow SANJU SYSTEM X.\nShizuku Status: Not Connected"
        ShizukuState.CONNECTED -> "Shizuku Status: Connected ✔\nOnly resolution commands are used, and each one asks your confirmation first."
    }

    private fun allowed(cmd: Array<out String>): Boolean =
        cmd.size >= 2 && cmd[0] == "wm" && cmd[1] == "size" &&
            (cmd.size == 2 || (cmd.size == 3 && (cmd[2] == "reset" || sizeArg.matches(cmd[2]))))

    suspend fun exec(vararg cmd: String): Result = withContext(Dispatchers.IO) {
        if (!allowed(cmd)) return@withContext Result(-1, "Command not allowed")
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf(*cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            Result(p.waitFor(), (out + err).trim())
        } catch (e: Throwable) {
            Result(-1, e.message ?: e.javaClass.simpleName)
        }
    }
}
