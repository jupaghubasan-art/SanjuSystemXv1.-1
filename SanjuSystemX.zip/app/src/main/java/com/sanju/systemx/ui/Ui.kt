package com.sanju.systemx.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch

object Pal {
    var dark = true
    var haptic = true
    var anim = true
    val RED: Int = 0xFFE5173F.toInt()
    val GREEN: Int = 0xFF2ECC71.toInt()
    val WHITE: Int = 0xFFFFFFFF.toInt()
    val bg: Int get() = if (dark) 0xFF09090B.toInt() else 0xFFF1F1F4.toInt()
    val panel: Int get() = if (dark) 0xFF17171B.toInt() else 0xFFFFFFFF.toInt()
    val panel2: Int get() = if (dark) 0xFF26262C.toInt() else 0xFFE4E4EA.toInt()
    val text: Int get() = if (dark) 0xFFEDEDED.toInt() else 0xFF121214.toInt()
    val sub: Int get() = if (dark) 0xFF9A9AA3.toInt() else 0xFF55555E.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.label(t: String, sp: Float = 14f, color: Int = Pal.text, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.vbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(14), dp(10), dp(14), dp(16))
}

/** Dark panel with a red HUD border and an optional title. */
fun Context.box(title: String? = null): LinearLayout {
    val l = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(14))
        background = GradientDrawable().apply {
            setColor(Pal.panel)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), 0x66E5173F)
        }
    }
    if (title != null) l.addView(label(title, 12f, Pal.RED, true).apply { letterSpacing = 0.15f })
    return l
}

fun LinearLayout.put(v: View, top: Int = 10): LinearLayout {
    addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { topMargin = context.dp(top) })
    return this
}

fun Context.btn(t: String, filled: Boolean = true, onClick: (View) -> Unit): MaterialButton =
    MaterialButton(this).apply {
        text = t
        setTextColor(if (filled) Pal.WHITE else Pal.RED)
        backgroundTintList = ColorStateList.valueOf(if (filled) Pal.RED else Pal.panel2)
        cornerRadius = dp(10)
        minimumHeight = dp(48)
        setOnClickListener {
            if (Pal.haptic) it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            onClick(it)
        }
    }

fun Context.chips(options: List<String>, selected: String?, required: Boolean = true, onSel: (String) -> Unit): ChipGroup {
    val g = ChipGroup(this).apply { isSingleSelection = true; isSelectionRequired = required }
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    val bgc = ColorStateList(states, intArrayOf(Pal.RED, Pal.panel2))
    val tc = ColorStateList(states, intArrayOf(Pal.WHITE, Pal.text))
    options.forEach { o ->
        g.addView(Chip(this).apply {
            id = View.generateViewId()
            text = o
            isCheckable = true
            isCheckedIconVisible = false
            chipBackgroundColor = bgc
            setTextColor(tc)
            isChecked = (o == selected)
            setOnClickListener { onSel(o) }
        })
    }
    return g
}

fun Context.switchRow(t: String, on: Boolean, onChange: (Boolean) -> Unit): MaterialSwitch =
    MaterialSwitch(this).apply {
        text = t
        setTextColor(Pal.text)
        isChecked = on
        setOnCheckedChangeListener { v, c ->
            if (Pal.haptic) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            onChange(c)
        }
    }
