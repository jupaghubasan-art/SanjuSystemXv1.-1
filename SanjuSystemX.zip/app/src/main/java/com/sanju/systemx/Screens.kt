package com.sanju.systemx

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.res.ColorStateList
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.app.ActivityManager
import android.content.Context
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.ChipGroup
import com.sanju.systemx.gaming.Game
import com.sanju.systemx.gaming.GameScanner
import com.sanju.systemx.monitor.Monitor
import com.sanju.systemx.optimizer.Action
import com.sanju.systemx.optimizer.Preset
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import androidx.appcompat.app.AlertDialog
import com.sanju.systemx.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private fun fmt(f: Float, d: Int = 1): String = String.format(Locale.US, "%.${d}f", f)
private fun List<Action>.render(): String = joinToString("\n\n") { "${it.mark} ${it.text}" }

// ───────────────────────── DASHBOARD ─────────────────────────
fun MainActivity.dashboardScreen(): View {
    val act = this
    val root = vbox()
    root.put(box().apply {
        put(label("SANJU SYSTEM X", 28f, Pal.RED, true).apply { letterSpacing = 0.08f }, 0)
        put(label("DOMINATE • OPTIMIZE • PLAY BETTER", 13f), 4)
        put(label("Only actions Android really permits are performed. Everything else is labelled honestly.", 12f, Pal.sub), 8)
    }, 0)

    var sel = Preset.BALANCED
    val desc = label(sel.desc, 13f, Pal.sub)
    val result = label("", 13f)
    val prog = ProgressBar(this).apply {
        isIndeterminate = true
        indeterminateTintList = ColorStateList.valueOf(Pal.RED)
        visibility = View.GONE
    }
    val group = chips(Preset.values().map { it.title }, sel.title) { t ->
        sel = Preset.values().first { it.title == t }
        desc.text = sel.desc
    }
    root.put(box("QUICK OPTIMIZATION").apply {
        put(group, 8)
        put(desc, 6)
        put(btn("APPLY PRESET") { v ->
            v.isEnabled = false; prog.visibility = View.VISIBLE; result.text = ""
            act.lifecycleScope.launch {
                delay(700)
                val actions = optimizer.apply(sel)
                prog.visibility = View.GONE; v.isEnabled = true
                result.text = "Actions performed:\n\n" + actions.render()
            }
        }, 12)
        put(prog, 8)
        put(result, 8)
    })
    root.put(box("HOW TO READ RESULTS").apply {
        put(label("✔ done   ℹ not possible / informational   ✖ failed", 12f, Pal.sub), 4)
    })
    return root
}

// ───────────────────────── RESOLUTION ─────────────────────────
private fun MainActivity.confirmRun(msg: String, onOk: () -> Unit) {
    AlertDialog.Builder(this).setTitle("Run this command?").setMessage(msg)
        .setPositiveButton("RUN") { _, _ -> onOk() }
        .setNegativeButton("CANCEL", null).show()
}

/** Safety net: reverts automatically after 15 s unless the user taps KEEP. */
private fun MainActivity.keepOrRevert(out: TextView) {
    val d = AlertDialog.Builder(this).setTitle("Keep this resolution?")
        .setMessage("Reverting in 15 s…").setCancelable(false)
        .setPositiveButton("KEEP") { _, _ -> out.text = "✔ Resolution kept." }
        .setNegativeButton("REVERT NOW") { _, _ ->
            lifecycleScope.launch {
                ShizukuBridge.exec("wm", "size", "reset")
                out.text = "✔ Reverted to native resolution."
            }
        }.create()
    d.show()
    lifecycleScope.launch {
        for (i in 14 downTo 0) {
            delay(1000)
            if (!d.isShowing) return@launch
            d.setMessage("Reverting in $i s…")
        }
        if (d.isShowing) {
            d.dismiss()
            ShizukuBridge.exec("wm", "size", "reset")
            out.text = "✔ No answer, so the resolution was reverted to native."
        }
    }
}

fun MainActivity.resolutionScreen(): View {
    val act = this
    val root = vbox()
    val (pw, ph) = DisplayCtl.resolution(this)
    var pct = Math.round(prefs.getF("scale", 1f) * 100).coerceIn(50, 100)
    val info = label("", 13f)
    val out = label("", 13f)
    lateinit var seek: SeekBar
    lateinit var group: ChipGroup

    fun refreshInfo() {
        val s = pct / 100f
        info.text = "Scale ${fmt(s, 2)}x → about ${(pw * s).toInt()} × ${(ph * s).toInt()} (native $pw × $ph)\n" +
            "Pixels rendered: ${Math.round(s * s * 100)}% of normal"
    }

    val presets = listOf(50, 60, 70, 80, 90, 100)
    val labels = presets.map { fmt(it / 100f) + "x" }
    group = chips(labels, labels.firstOrNull { it == fmt(pct / 100f) + "x" }, false) { l ->
        pct = presets[labels.indexOf(l)]
        seek.progress = pct - 50
        refreshInfo()
    }
    seek = SeekBar(this).apply {
        max = 50
        progress = pct - 50
        progressTintList = ColorStateList.valueOf(Pal.RED)
        thumbTintList = ColorStateList.valueOf(Pal.RED)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                pct = p + 50; refreshInfo(); if (fromUser) group.clearCheck()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }
    refreshInfo()

    root.put(box("RESOLUTION SCALE").apply {
        put(group, 6)
        put(label("Custom downscale", 12f, Pal.sub), 8)
        put(seek, 2)
        put(info, 10)
        put(btn("APPLY RESOLUTION") {
            prefs.setF("scale", pct / 100f)
            if (ShizukuBridge.state(act) != ShizukuState.CONNECTED) {
                out.text = "ℹ Saved ${fmt(pct / 100f, 2)}x. Not applied: connect Shizuku below first. Normal apps cannot change system resolution."
                return@btn
            }
            act.lifecycleScope.launch {
                val phys = ShizukuBridge.exec("wm", "size")
                val m = Regex("Physical size: (\\d+)x(\\d+)").find(phys.out)
                if (m == null) { out.text = "✖ Could not read the screen size: ${phys.out}"; return@launch }
                val s = pct / 100f
                val tw = (m.groupValues[1].toInt() * s).toInt() and -2
                val th = (m.groupValues[2].toInt() * s).toInt() and -2
                confirmRun("Shizuku will run:\n\nwm size ${tw}x$th\n\nThis changes your whole screen resolution (all apps). You will get 15 seconds to keep or revert it.") {
                    act.lifecycleScope.launch {
                        val r = ShizukuBridge.exec("wm", "size", "${tw}x$th")
                        if (r.code != 0) { out.text = "✖ Failed (${r.code}): ${r.out}"; return@launch }
                        out.text = "✔ Resolution set to $tw × $th"
                        keepOrRevert(out)
                    }
                }
            }
        }, 12)
        put(btn("RESET", false) {
            pct = 100; seek.progress = 50; group.clearCheck(); prefs.setF("scale", 1f); refreshInfo()
            if (ShizukuBridge.state(act) == ShizukuState.CONNECTED) {
                confirmRun("Shizuku will run:\n\nwm size reset") {
                    act.lifecycleScope.launch {
                        val r = ShizukuBridge.exec("wm", "size", "reset")
                        out.text = if (r.code == 0) "✔ Native resolution restored." else "✖ Failed (${r.code}): ${r.out}"
                    }
                }
            } else out.text = "✔ Saved scale reset to 1.0x. If you changed the size earlier, restore it with: adb shell wm size reset"
        }, 8)
        put(out, 10)
    })

    val st = label(ShizukuBridge.statusText(this), 13f)
    root.put(box("ADVANCED · SHIZUKU").apply {
        put(st, 6)
        put(btn("CONNECT / CHECK SHIZUKU", false) {
            if (ShizukuBridge.state(act) == ShizukuState.NEEDS_PERMISSION) ShizukuBridge.requestPermission()
            st.text = ShizukuBridge.statusText(act)
            act.lifecycleScope.launch {
                for (i in 0 until 30) {
                    delay(500)
                    st.text = ShizukuBridge.statusText(act)
                    if (ShizukuBridge.state(act) == ShizukuState.CONNECTED) break
                }
            }
        }, 10)
        put(label("No root needed. No command runs silently.", 12f, Pal.sub), 6)
    })
    return root
}

// ───────────────────────── GAMING ─────────────────────────
fun MainActivity.gamingScreen(): View {
    val act = this
    val root = vbox()
    var fps = prefs.getS("fps", "60 FPS")
    var gfx = prefs.getS("gfx", "High")
    val rates = DisplayCtl.rates(this)
    var rate = rates.firstOrNull { it.modeId == prefs.getI("mode", 0) } ?: rates.firstOrNull { it.hz == DisplayCtl.hz(act) }
    val out = label("", 13f)

    root.put(box("FPS MODE").apply {
        put(chips(listOf("30 FPS", "60 FPS", "90 FPS", "120 FPS", "144 FPS"), fps) { fps = it }, 6)
        put(label("Not directly controllable by Android. Saved as your target; set it in the game.", 12f, Pal.sub), 4)
    }, 0)
    root.put(box("GRAPHICS").apply {
        put(chips(listOf("Low", "Medium", "High", "Very High", "Max", "Ultra"), gfx) { gfx = it }, 6)
        put(label("Requires device/game support. Cannot be forced from outside the game.", 12f, Pal.sub), 4)
    })
    root.put(box("REFRESH RATE · REAL").apply {
        put(label("Current: ${DisplayCtl.hz(act)} Hz   Available: " +
            (if (rates.isEmpty()) "unknown" else rates.joinToString(", ") { "${it.hz} Hz" }), 13f), 4)
        if (rates.size > 1) put(chips(rates.map { "${it.hz} Hz" }, rate?.let { "${it.hz} Hz" }) { l ->
            rate = rates.first { "${it.hz} Hz" == l }
        }, 6)
        else put(label("This display reports a single refresh rate, so there is nothing to switch.", 12f, Pal.sub), 4)
    })
    root.put(box("ANIME MODE").apply {
        put(switchRow("Anime mode (visual filter)", prefs.getB("anime", false)) {
            prefs.setB("anime", it); applyAnime(it)
        }, 4)
        put(label("Boosts saturation/contrast of THIS app's UI only. It does not modify or filter any game.", 12f, Pal.sub), 4)
    })

    // Game selection
    var games: List<Game> = emptyList()
    var selected = prefs.getS("game", "")
    var showAll = false
    val list = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
    fun render() {
        list.removeAllViews()
        if (games.isEmpty()) list.addView(label("No games found. Turn on \"Show all apps\".", 12f, Pal.sub))
        games.forEach { g ->
            val row = label((if (g.isMl) "★ " else "") + g.label, 14f, if (g.pkg == selected) Pal.WHITE else Pal.text).apply {
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundColor(if (g.pkg == selected) Pal.RED else Pal.panel2)
                setOnClickListener { selected = g.pkg; prefs.setS("game", g.pkg); render() }
            }
            list.put(row, 6)
        }
    }
    fun load() {
        act.lifecycleScope.launch {
            games = withContext(Dispatchers.IO) { GameScanner.scan(act, showAll) }
            render()
        }
    }
    root.put(box("GAME SELECTION").apply {
        put(switchRow("Show all apps", false) { showAll = it; load() }, 4)
        put(list, 4)
        put(btn("LAUNCH SELECTED GAME", false) {
            val i = if (selected.isEmpty()) null else packageManager.getLaunchIntentForPackage(selected)
            if (i == null) Toast.makeText(act, "Select a game first", Toast.LENGTH_SHORT).show() else startActivity(i)
        }, 10)
    })
    load()

    root.put(btn("APPLY GAMING SETTINGS") {
        prefs.setS("fps", fps); prefs.setS("gfx", gfx)
        val acts = mutableListOf<Action>()
        val r = rate
        if (r != null && rates.size > 1) acts += optimizer.refresh(r.modeId, r.hz)
        else acts += Action("ℹ", "Refresh rate unchanged (no alternative mode on this display).")
        acts += optimizer.keepAwake(prefs.getB("awake", false))
        acts += optimizer.gameNote(fps, gfx)
        out.text = acts.render()
    }, 14)
    root.put(out, 10)
    return root
}

// ───────────────────────── MONITOR ─────────────────────────
private fun MainActivity.deviceText(): String {
    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
    val sf = StatFs(Environment.getDataDirectory().path)
    val (w, h) = DisplayCtl.resolution(this)
    return "Model: ${Build.MODEL}\nManufacturer: ${Build.MANUFACTURER}\nAndroid: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n" +
        "RAM: ${fmt(mi.totalMem / 1073741824f)} GB\nFree storage: ${fmt(sf.availableBytes / 1073741824f)} GB\n" +
        "Screen: $w × $h\nRefresh rate: ${DisplayCtl.hz(this)} Hz"
}

fun MainActivity.monitorScreen(): View {
    val act = this
    val root = vbox()
    val fpsChart = LineChartView(this, "FPS · this app's own rendering", null)
    val ramChart = LineChartView(this, "System RAM used %", 100f)
    val metrics = label("Press START to measure.", 13f)
    val probe = View(this).apply { setBackgroundColor(Pal.RED) }
    var started = false

    fun begin() {
        if (started) return
        started = true
        monitor.start()
        probeAnim = ObjectAnimator.ofFloat(probe, "rotation", 0f, 360f).apply {
            duration = 1200; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator(); start()
        }
        monitorJob = act.lifecycleScope.launch {
            while (isActive) {
                delay(1000)
                val s = monitor.sample()
                fpsChart.push(s.fps); ramChart.push(s.ramPct)
                metrics.text = "FPS (render probe): ${Math.round(s.fps)}\nCPU: ${s.cpu}\nCPU load: Unavailable through public Android API\n" +
                    "GPU utilization: Unavailable through public Android API\nSystem RAM: ${s.ramText}\nThis app's heap: ${s.heapMb} MB\n" +
                    "Battery: ${if (s.battery >= 0) "${s.battery}%" else "n/a"}${if (s.charging) " (charging)" else ""}\n" +
                    "Battery temperature: ${s.tempC?.let { fmt(it) + " °C" } ?: "Unavailable"}\nRefresh rate: ${DisplayCtl.hz(act)} Hz"
            }
        }
    }

    root.put(box("LIVE MONITOR").apply {
        put(fpsChart, 6); put(ramChart, 6)
        put(android.widget.LinearLayout(act).apply {
            addView(label("Render probe (needed to measure FPS): ", 11f, Pal.sub))
            addView(probe, android.widget.LinearLayout.LayoutParams(dp(12), dp(12)))
        }, 6)
        put(metrics, 8)
        if (!prefs.getB("autoMon", true)) put(btn("START MONITOR") { v -> v.isEnabled = false; begin() }, 8)
    }, 0)
    root.put(box("DEVICE INFORMATION").apply { put(label(deviceText(), 13f), 6) })
    if (prefs.getB("autoMon", true)) begin()
    return root
}

// ───────────────────────── SETTINGS ─────────────────────────
fun MainActivity.settingsScreen(): View {
    val root = vbox()
    root.put(box("SETTINGS").apply {
        put(switchRow("Dark theme", prefs.getB("dark", true)) { prefs.setB("dark", it); recreate() }, 4)
        put(switchRow("Animations", prefs.getB("anim", true)) { prefs.setB("anim", it); Pal.anim = it }, 4)
        put(switchRow("Haptic feedback", prefs.getB("haptic", true)) { prefs.setB("haptic", it); Pal.haptic = it }, 4)
        put(switchRow("Auto monitor", prefs.getB("autoMon", true)) { prefs.setB("autoMon", it) }, 4)
        put(switchRow("Keep screen awake", prefs.getB("awake", false)) { optimizer.keepAwake(it) }, 4)
        put(btn("RESET SETTINGS", false) {
            prefs.clear(); DisplayCtl.reset(this@settingsScreen); applyAnime(false)
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); recreate()
        }, 12)
    }, 0)
    root.put(box("PERMISSIONS").apply {
        put(label("This app requests no permissions. Game detection uses Android's launcher-app package visibility only. No network access, no tracking, no ads.", 13f, Pal.sub), 6)
    })
    root.put(box("ABOUT").apply {
        put(label("SANJU SYSTEM X", 16f, Pal.RED, true), 6)
        put(label("Android Game Optimizer\nVersion 1.1.0\n\nDeveloper:\nSanju", 13f), 4)
    })
    return root
}
