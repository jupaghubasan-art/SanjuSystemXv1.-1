# SANJU SYSTEM X — Android Game Optimizer

Package `com.sanju.systemx` · Kotlin · Material 3 · minSdk 26 · no permissions · no root.

## Build the APK from your phone (GitHub Actions)
1. Open github.com in Chrome and sign in (menu ⋮ → tick "Desktop site" if buttons are missing).
2. Tap **+** (top right) → **New repository**.
3. Repository name: `SanjuSystemX`. Choose **Public**. Tap **Create repository**.
4. Tap **uploading an existing file** (or **Add file → Upload files**). Pick `SanjuSystemX.zip` from Downloads. Tap **Commit changes**.
   (The workflow unpacks the zip automatically.)
5. Tap **Add file → Create new file**. In the name box type exactly `.github/workflows/build.yml` (typing `/` creates folders).
   Paste the full contents of `build.yml` from this project. Tap **Commit changes**.
6. Tap the **Actions** tab. If asked, tap **I understand my workflows, enable them**.
7. Tap **Build APK** in the left list (or the ☰ workflow menu).
8. Tap **Run workflow** → green **Run workflow**.
9. Wait 4–8 minutes. A yellow dot becomes a green ✔.
10. Tap the finished run (top of the list).
11. Scroll to **Artifacts**.
12. Tap **SanjuSystemX-debug-apk** to download a zip, open it with Files, extract the `.apk`.
13. Tap the `.apk`. If asked, allow "Install unknown apps" for your Files/Chrome app, then tap **Install**.

## If the build fails
Open the failed run → tap the red step → copy the first lines starting with `e:` or `error:` and send them to me
with the file name and line shown. Common causes: wrong folder structure (the `app/` folder must be at the repo root),
`build.yml` not at `.github/workflows/build.yml`, or a typo when pasting.

## What is REAL
- Refresh-rate detection and switching (`preferredDisplayModeId`, this app's window only; Android may override).
- Live FPS of this app's own rendering, system RAM, app heap, battery %, battery temperature, per-core CPU frequency (when the device allows reading it).
- Device info, installed-game detection via launcher package visibility, launching a game, keep-screen-awake, clearing this app's own cache.
- Anime mode: a colour filter on this app's UI only.

## What Android does NOT allow (labelled in the app)
- Forcing a game's FPS or graphics level; system-wide resolution change (needs ADB/Shizuku); CPU/GPU load readings (not public APIs);
  modifying or filtering games. The app never injects into, patches or touches Mobile Legends.

## Shizuku (v1.1)
Resolution > Connect Shizuku: start Shizuku (Wireless debugging), tap the button, allow the app. Apply/Reset then run `wm size` only after you confirm the exact command; a 15 s keep/revert timer protects you.

## Shizuku (old notes)
The app detects whether the Shizuku app is installed and always shows "Not Connected" because this build has no Shizuku API integration.
`shizuku/ShizukuBridge.kt` contains the `PrivilegedOps` interface where future, user-confirmed operations can be added.

## Project layout
`ui/` helpers & chart · `monitor/` metrics · `optimizer/` presets/actions · `gaming/` game scan · `resolution/` display modes · `shizuku/` bridge · `settings/` prefs.
